from datetime import datetime
import json
import requests

base_url="http://localhost:4000"
investigate_api_key = "41801821-b9a1-4ad3-82d9-dfe2c93ff9ef"
#create header for authentication and set limit of sample return to 1
headers = {
'Authorization': 'Bearer ' + investigate_api_key,
'limit': '1'
}

def retrieve_categorie(header):
    api_path = "/domains/categorization"
    get_url = f"{base_url}{api_path}"
    # do GET request for the domain status and category
    request_get = requests.get(get_url, headers=headers)
    if(request_get.status_code == 200):
        # store all categories into a variable named output
        output = request_get.json() 
        return output


if __name__ == '__main__':
    categories=retrieve_categorie(headers)
    print(categories)
    '''
    for cle,valeur in categories.items():
        print (cle+' '+ valeur)
    '''
    