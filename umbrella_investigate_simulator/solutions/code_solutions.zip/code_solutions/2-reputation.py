from datetime import datetime
import json
import requests

#base_url="https://investigate.api.umbrella.com"
base_url="http://localhost:4000"
investigate_api_key = "31801821-b9a1-4ad3-82d9-dfe2c93ff9ef"
#create header for authentication and set limit of sample return to 1
headers = {
'Authorization': 'Bearer ' + investigate_api_key,
'limit': '1'
}

def check_reputation(header,file):
    api_path = "/domains/categorization/"
    get_url = f"{base_url}{api_path}"
    # time for AlertTime and EventTime when domains are added to Umbrella
    time = datetime.now().isoformat()
        
    # loop through domain.txt file and append every domain to list, skip comments
    domain_list = []
    with open('domains.txt') as inputfile:
        for line in inputfile:
            if line[0] == "#" or line.strip() == "Site":
                pass
            else:
                domain_list.append(line.strip())

    fi = open("reputation.txt", "w")
    # loop through all domains
    for domain in domain_list:
        print(domain)
        # assemble the URI, show labels give readable output
        api_path = "/domains/categorization/"
        get_url = f"{base_url}{api_path}{domain}"        
        # do GET request for the domain status and category
        request_get = requests.get(get_url, headers=headers)
        if(request_get.status_code == 200):
            # store categorization into the output variable
            output = request_get.json()
            resp2=json.dumps(output,sort_keys=True,indent=4, separators=(',', ': '))
            print(resp2)
            # FIRST let's retreive the domain status
            domain_output = output[domain] #we need this as the domain name in the json result is always changing
            domain_status = domain_output["status"] #a now we can retreive the status for the domain name
            # walk through different options of status
            if(domain_status == -1):
                print("SUCCESS: The domain %(domain)s is found MALICIOUS at %(time)s" % {'domain': domain, 'time': time})
                fi.write(domain+'; DANGEROUS ;'+time+';')
            elif(domain_status == 1):
                print("SUCCESS: The domain %(domain)s is found CLEAN at %(time)s" % {'domain': domain, 'time': time})
                fi.write(domain+'; CLEAN ;'+time+';')            
            else:
                print("SUCCESS: The domain %(domain)s is found UNDEFINED / RISKY at %(time)s" % {'domain': domain, 'time': time})
                fi.write(domain+'; UNKNOWN;'+time+';')
            fi.write('\r\n')

    
def check_categorization(header,file,categories):
    api_path = "/domains/categorization/"
    get_url = f"{base_url}{api_path}"
    # time for AlertTime and EventTime when domains are added to Umbrella
    time = datetime.now().isoformat()
        
    # loop through domain.txt file and append every domain to list, skip comments
    domain_list = []
    with open('domains.txt') as inputfile:
        for line in inputfile:
            if line[0] == "#" or line.strip() == "Site":
                pass
            else:
                domain_list.append(line.strip())
    fi = open("resultat_reputation.txt", "w")
    # loop through all domains
    for domain in domain_list:
        print(domain)
        # assemble the URI, show labels give readable output
        api_path = "/domains/categorization/"
        get_url = f"{base_url}{api_path}{domain}"        
        # do GET request for the domain status and category
        request_get = requests.get(get_url, headers=headers)
        if(request_get.status_code == 200):
            # store categorization into the output variable
            output = request_get.json()
            resp2=json.dumps(output,sort_keys=True,indent=4, separators=(',', ': '))
            print(resp2)
            # FIRST let's retreive the domain status
            domain_output = output[domain] #we need this as the domain name in the json result is always changing
            domain_status = domain_output["status"] #a now we can retreive the status for the domain name
            # walk through different options of status
            if(domain_status == -1):
                print("SUCCESS: The domain %(domain)s is found MALICIOUS at %(time)s" % {'domain': domain, 'time': time})
                fi.write(domain+'; DANGEROUS ;'+time+';')
            elif(domain_status == 1):
                print("SUCCESS: The domain %(domain)s is found CLEAN at %(time)s" % {'domain': domain, 'time': time})
                fi.write(domain+'; CLEAN ;'+time+';')            
            else:
                print("SUCCESS: The domain %(domain)s is found UNDEFINED / RISKY at %(time)s" % {'domain': domain, 'time': time})
                fi.write(domain+'; UNKNOWN;'+time+';')
            # SECOND let's retreive Domain Categories
            domain_categories=[]
            domain_categories = domain_output["content_categories"]
            for cat in domain_categories:
                la_categorie=categories.get(cat)
                print (la_categorie)
                fi.write(la_categorie +' + ')
            fi.write('\r\n')  

if __name__ == '__main__':
    check_reputation(headers,'domains.txt')
    